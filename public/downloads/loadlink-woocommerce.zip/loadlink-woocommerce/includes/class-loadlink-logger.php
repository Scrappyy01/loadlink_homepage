<?php
class Loadlink_Logger {
    public static function log($message, $level = 'info') {
        wc_get_logger()->log($level, $message, ['source' => 'loadlink']);
    }
}
