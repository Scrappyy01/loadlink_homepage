<?php
class Loadlink_API {
    public function get_rates($payload) {
        // Implement API call here
        return [];
    }
}
