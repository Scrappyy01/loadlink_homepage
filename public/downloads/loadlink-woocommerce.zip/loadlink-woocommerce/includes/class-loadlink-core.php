<?php
class Loadlink_Core {
    public function init() {
        add_action('woocommerce_shipping_init', [$this, 'load_shipping_method']);
        add_filter('woocommerce_shipping_methods', [$this, 'register_shipping_method']);
    }

    public function load_shipping_method() {
        require_once LOADLINK_PLUGIN_PATH . 'includes/class-loadlink-method.php';
    }

    public function register_shipping_method($methods) {
        $methods['loadlink'] = 'Loadlink_Shipping_Method';
        return $methods;
    }
}
