<?php
// Shared utility functions can go here
