<?php
class Loadlink_Shipment {
    // Optional shipment handling logic
}
