<?php
class Loadlink_Log {
    public static function info($message) {
        wc_get_logger()->info($message, ['source' => 'loadlink']);
    }

    public static function error($message) {
        wc_get_logger()->error($message, ['source' => 'loadlink']);
    }
}
