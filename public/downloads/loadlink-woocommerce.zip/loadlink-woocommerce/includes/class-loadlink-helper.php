<?php
class Loadlink_Helper {
    // Shared utility functions
}
