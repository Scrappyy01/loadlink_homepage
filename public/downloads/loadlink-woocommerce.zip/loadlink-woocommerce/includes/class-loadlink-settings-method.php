<?php
class Loadlink_Settings_Method {
    // Future settings logic
}
