<?php
class Loadlink_Data_Mapper_Order {
    public function map($order) {
        // Return API payload from Woo Order
        return [];
    }
}
