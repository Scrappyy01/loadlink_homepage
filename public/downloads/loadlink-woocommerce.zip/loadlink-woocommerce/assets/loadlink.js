// JS for admin UI toggle functionality
