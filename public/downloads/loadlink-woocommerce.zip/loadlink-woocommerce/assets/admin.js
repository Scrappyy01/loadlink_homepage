// JS for admin settings toggle if needed
