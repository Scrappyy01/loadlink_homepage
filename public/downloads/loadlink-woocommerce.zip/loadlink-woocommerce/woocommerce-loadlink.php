<?php
/**
 * Plugin Name: Loadlink Parcel Freight for WooCommerce
 * Description: Provides live shipping rates from the Loadlink platform.
 * Version: 1.0.0
 * Author: Loadlink
 * Text Domain: loadlink
 */

if (!defined('ABSPATH')) exit;

define('LOADLINK_VERSION', '1.0.0');
define('LOADLINK_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('LOADLINK_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once LOADLINK_PLUGIN_PATH . 'includes/class-loadlink-plugin.php';

function loadlink_init() {
    $plugin = new Loadlink_Plugin();
    $plugin->init();
}
add_action('woocommerce_init', 'loadlink_init');
