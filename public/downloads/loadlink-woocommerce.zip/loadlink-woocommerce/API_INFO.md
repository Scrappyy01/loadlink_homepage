There is a get_price POST endpoint.

get_price
{{baseUrl}}/api/v1/partner/freight/get_price
https://devapi.loadlink.net.au/

Sample post to the endpoint:
{
    "pickup_suburb": "SOUTHPORT, 4215, QLD",
    "delivery_suburb": "COOMBABAH, 4216, QLD",
    "delivery_building_type": "Residential",
    "pickup_building_type": "Residential",
    "dataRows": [
        {
            "packagingType": "CR",
            "qty": 3,
            "kgs": 3,
            "length": 3,
            "width": 3,
            "height": 3,
            "weight": 9,
            "volume": 27
        },
        {
            "packagingType": "DR",
            "qty": 6,
            "kgs": 7,
            "length": 8,
            "width": 9,
            "height": 99,
            "weight": 42,
            "volume": 7128
        }
    ],
    "is_danger": false,
    "user_id": 6
}

Sample response from that post:
{
    "road express": {
        "type": "Couriers Please",
        "name": "road express",
        "code": "L55",
        "quote": "38.57",
        "user_price": "44.36",
        "gst_price": 4.44,
        "currency": "AUD",
        "collection_cutoff_time": "15:59",
        "estimated_delivery_datetime": "2025-10-16 04:49:13",
        "service_quote_id": 734
    },
    "overnight express": {
        "type": "Fed Ex",
        "name": "overnight express",
        "code": "75",
        "quote": "134.2",
        "user_price": "154.33",
        "gst_price": 15.43,
        "currency": "AUD",
        "collection_cutoff_time": "15:00:00",
        "estimated_delivery_datetime": "2025-10-10T17:00:00",
        "service_quote_id": 735
    },
    "air express": [],
    "asap hot shot": [],
    "technology express": {
        "type": "Fed Ex",
        "name": "technology express",
        "code": "717B",
        "quote": "84.48",
        "user_price": "97.15",
        "gst_price": 9.72,
        "currency": "AUD",
        "collection_cutoff_time": "15:00:00",
        "estimated_delivery_datetime": "2025-10-14T17:00:00",
        "service_quote_id": 736
    },
    "freight_id": 644,
    "freight_created_at": "2025-10-07T04:49:11.000000Z"
}


this is the app we're going to simulate in the plugin: https://parcelfreight.loadlink.com.au/parcel-freight/